# IMPORTS
from player import Player
from game_platform import Platform
import os


os.environ['SDL_VIDEO_CENTERED'] = '1'

# SCREEN SETTINGS
WIDTH = 1000
HEIGHT = 700
TITLE = "Polarity"

# CREATE PLAYER
player = Player(100, 300)

# CREATE PLATFORMS
platforms = [
    Platform(0, 650, 1000, 50),
    Platform(300, 500, 200, 20),
    Platform(600, 400, 200, 20)
]

# UPDATE FUNCTION
def update():

    player.update(platforms)
    

# DRAW FUNCTION
def draw():
    screen.clear()

    for platform in platforms:
        platform.draw(screen)

    player.draw(screen)

def on_key_down(key):
    if key == keys.G:
        player.flip_gravity()