from pgzero.builtins import Rect, keyboard

class Player:

    def __init__(self, x, y):
        self.rect = Rect((x, y), (40, 40))
        
        
        self.vel_y = 0
        self.speed = 5
        
        self.gravity = 0.5
        self.on_ground = False

    def update(self, platforms):

        #movement
        if keyboard.a:
            self.rect.x -= self.speed

        if keyboard.d:
            self.rect.x += self.speed

        #gravity
        self.vel_y += self.gravity
        self.rect.y += self.vel_y

        #collision
        self.on_ground = False

        for p in platforms:
            if self.rect.colliderect(p.rect):

                # landing on top of platform
                if self.vel_y > 0:
                    self.rect.bottom = p.rect.top
                    self.vel_y = 0
                    self.on_ground = True
                    
        #jump
        if keyboard.w and self.on_ground:
            self.vel_y = -10

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "cyan")
        
    def flip_gravity(self):
        self.gravity *= -1
        self.vel_y *= -1