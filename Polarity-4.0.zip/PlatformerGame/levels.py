from game_platform import Platform, Lava, Ice, Speed, Mud, Finish

LEVELS = [
    {
        "player_start": (100, 500),
        "finish": (900, 100, 50, 50),

        "platforms": [
            Platform(0, 650, 1000, 50),
            Platform(0, 0, 1000, 50),
            Platform(0, 0, 30, 700),
            Platform(970, 0, 30, 700),

            Ice(250, 500, 200, 20),
            Lava(500, 450, 200, 20),
            Speed(750, 350, 150, 20),
        ]
    },

    {
        "player_start": (100, 500),
        "finish": (900, 120, 50, 50),

        "platforms": [
            Platform(0, 650, 1000, 50),
            Platform(0, 0, 1000, 50),
            Platform(0, 0, 30, 700),
            Platform(970, 0, 30, 700),

            Mud(200, 600, 200, 20),
            Ice(450, 500, 200, 20),
            Speed(700, 400, 150, 20),
            Lava(350, 300, 150, 20),
        ]
    },

    {
        "player_start": (100, 500),
        "finish": (920, 80, 50, 50),

        "platforms": [
            Platform(0, 650, 1000, 50),
            Platform(0, 0, 1000, 50),
            Platform(0, 0, 30, 700),
            Platform(970, 0, 30, 700),

            Ice(200, 550, 150, 20),
            Ice(400, 450, 150, 20),
            Mud(600, 350, 150, 20),
            Speed(800, 250, 150, 20),

            Lava(300, 200, 200, 20),
        ]
    }
]