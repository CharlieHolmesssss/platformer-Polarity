from pgzero.builtins import Rect

class Platform:

    def __init__(self, x, y, w, h, friction=0.5, speed_modifier=1.0):
        self.rect = Rect((x, y), (w, h))
        self.friction = friction
        self.speed_modifier = speed_modifier

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "grey")


class Lava(Platform):

    def __init__(self, x, y, w, h):
        super().__init__(x, y, w, h, friction=0.2, speed_modifier=1.0)

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "red")


class Ice(Platform):

    def __init__(self, x, y, w, h):
        super().__init__(x, y, w, h, friction=1.0,speed_modifier=1.5)

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "white")
        
class Speed(Platform):

    def __init__(self, x, y, w, h):
        super().__init__(x, y, w, h, friction=0.75, speed_modifier=3.0)

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "yellow")

class Mud(Platform):

    def __init__(self, x, y, w, h):
        super().__init__(x, y, w, h, friction=0.25, speed_modifier=0.5)

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "brown")

class Finish:

    def __init__(self, x, y, w, h):
        self.rect = Rect((x, y), (w, h))

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "green")