from game_platform import Platform

LEVELS = [
    {
        "player_start": (100, 500),
        "platforms": [
            Platform(0, 650, 1000, 50), #floor
            Platform(0, 0, 1000, 50),   #roof
            Platform(0, 0, 30, 700),    #left wall
            Platform(970, 0, 30, 700),  #right wall
            
            Platform(300, 500, 200, 20),
            Platform(600, 400, 200, 20),
        ]
    },

    {
        "player_start": (100, 500),
        "platforms": [
            Platform(0, 650, 1000, 50), #floor
            Platform(0, 0, 1000, 50),   #roof
            Platform(0, 0, 30, 700),    #left wall
            Platform(970, 0, 30, 700),  #right wall
            
            Platform(200, 550, 150, 20),
            Platform(450, 450, 150, 20),
            Platform(700, 350, 150, 20),
            
        ]
    }
]