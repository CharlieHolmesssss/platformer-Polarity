from pgzero.builtins import Rect

class Platform:

    def __init__(self, x, y, w, h):
        self.rect = Rect((x, y), (w, h))

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "white")
    