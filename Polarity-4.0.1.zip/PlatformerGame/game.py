# Imports
from player import Player
from levels import LEVELS
from game_platform import Lava, Platform, Ice, Mud, Speed, Finish
from pgzero.builtins import Rect, keys
import os
import pygame

# Center window
os.environ['SDL_VIDEO_CENTERED'] = '1'

# Screen settings
WIDTH = 1000
HEIGHT = 700
TITLE = "Polarity"

# Game state
player = None
platforms = []
current_level = 0
finish = None
game_state = "menu"  #menu, playing, paused

def init_game():
    #Reset the run and load the first level.
    global player, current_level

    current_level = 0
    load_level(current_level)


def load_level(index):
    #Load the player and platforms for one level.
    global player, platforms, finish

    level = LEVELS[index]

    player = Player(
        level["player_start"][0],
        level["player_start"][1]
    )

    platforms = level["platforms"]

    #Temporary finish zone.
    finish = Finish(
    level["finish"][0],
    level["finish"][1],
    level["finish"][2],
    level["finish"][3]
    )


def next_level():
    #Advance to the next level, if there is one.
    global current_level

    current_level += 1

    if current_level < len(LEVELS):
        load_level(current_level)
    else:
        print("Game complete!")


def update():

    if game_state != "playing":
        return

    player.update(platforms)

    if player.rect.colliderect(finish.rect):
        next_level()


def draw_button(text, rect, mouse_pos):
    hover = rect.collidepoint(mouse_pos)

    color = "lightblue" if hover else "blue"
    scale = 1.1 if hover else 1.0

    screen.draw.filled_rect(rect, color)

    screen.draw.text(
        text,
        center=rect.center,
        fontsize=int(45 * scale),
        color="white"
    )


def draw():

    screen.clear()

    if game_state == "menu":
        screen.draw.text(
            "POLARITY",
            center=(WIDTH//2, 200),
            fontsize=80,
            color="white"
        )

        play_button = Rect((400, 350), (200, 80))
        draw_button("PLAY", play_button, pygame.mouse.get_pos())

    elif game_state == "playing":
        for platform in platforms:
            platform.draw(screen)

        player.draw(screen)

        finish.draw(screen)
    
    elif game_state == "paused":
        screen.draw.text(
            "PAUSED",
            center=(WIDTH//2, HEIGHT//2 - 100),
            fontsize=80,
            color="white"
        )

        screen.draw.text(
            "Press ESC to resume",
            center=(WIDTH//2, HEIGHT//2),
            fontsize=40,
            color="grey"
        )


def on_key_down(key):
    global game_state

    if key == keys.ESCAPE:
        if game_state == "playing":
            game_state = "paused"

        elif game_state == "paused":
            game_state = "playing"

    if game_state == "playing":
        if key == keys.G:
            player.flip_gravity()

        if key == keys.RETURN:
            init_game()

        if key == keys.R:
            reset_level()
        

def on_mouse_down(pos):
    global game_state

    if game_state == "menu":
        play_button = Rect((400, 350), (200, 80))

        if play_button.collidepoint(pos):
            init_game()
            game_state = "playing"
        
def reset_level():
    load_level(current_level)

#The game starts on the menu screen.
