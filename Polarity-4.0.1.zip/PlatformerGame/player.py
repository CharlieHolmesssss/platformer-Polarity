from pgzero.builtins import Actor, Rect, keyboard

class Player:

    def __init__(self, x, y):
        self.rect = Rect((x, y), (15, 15))
        #self.sprite = Actor("player", (x, y))

        # Movement tuning for smoother control.
        self.accel = 0.5
        self.friction = 0.8

        self.vel_x = 0
        self.vel_y = 0
        self.base_speed = 5
        self.speed = 5

        self.gravity = 0.5
        self.on_ground = False

        #Small grace window so jump and flip still work just after leaving a surface.
        self.coyote_time = 0

    def gravity_direction(self):
        #Returns 1 for normal gravity and -1 for inverted gravity.
        return 1 if self.gravity > 0 else -1

    def update(self, platforms):

        #Count down the grace window each frame.
        if self.coyote_time > 0:
            self.coyote_time -= 1

        #Horizontal movement uses acceleration and friction for smoother motion.
        if keyboard.a:
            self.vel_x -= self.accel

        elif keyboard.d:
            self.vel_x += self.accel

        else:
            self.vel_x *= self.friction

        #Limit top speed so acceleration does not keep building.
        self.vel_x = max(min(self.vel_x, self.speed), -self.speed)

        self.rect.x += self.vel_x

        #Horizontal collisions before vertical movement.
        self.handle_x_collisions(platforms)

        #Apply gravity and then vertical collisions.
        self.vel_y += self.gravity
        self.rect.y += self.vel_y

        self.handle_collisions(platforms)

        #Let the player cut jumps short by releasing the key early.
        if not keyboard.w and self.vel_y * self.gravity_direction() < 0:
            self.vel_y *= 0.5

        if keyboard.w and self.on_ground:
            self.vel_y = -10 * self.gravity_direction()
        
        
        #self.sprite.pos = (self.rect.centerx, self.rect.centery)

    def flip_gravity(self):
        #Allow gravity flips while grounded or during the grace window.
        if self.coyote_time > 0:
            self.gravity *= -1
            self.vel_y = 0

            #Give a small kick so the flip feels immediate.
            self.vel_y = 2 * self.gravity_direction()

    def handle_collisions(self, platforms):

        self.on_ground = False

        for p in platforms:

            if self.rect.colliderect(p.rect):

                #Normal gravity: stand on top, block upward movement.
                if self.gravity > 0:

                    if self.vel_y > 0:
                        self.rect.bottom = p.rect.top
                        self.vel_y = 0
                        self.on_ground = True

                        #Refresh the grace window after landing.
                        self.coyote_time = 6

                        #Surface friction and speed mod
                        self.friction = p.friction
                        self.speed = self.base_speed * p.speed_modifier

                    elif self.vel_y < 0:
                        self.rect.top = p.rect.bottom
                        self.vel_y = 0

                #Inverted gravity: stand on the underside, block downward movement.
                else:

                    if self.vel_y < 0:
                        self.rect.top = p.rect.bottom
                        self.vel_y = 0
                        self.on_ground = True

                        #Refresh the grace window after landing.
                        self.coyote_time = 6

                        #Surface friction and speed mod
                        self.friction = p.friction
                        self.speed = self.base_speed * p.speed_modifier

                    elif self.vel_y > 0:
                        self.rect.bottom = p.rect.top
                        self.vel_y = 0

    def handle_x_collisions(self, platforms):

        for p in platforms:

            if self.rect.colliderect(p.rect):

                if self.vel_x > 0:
                    self.rect.right = p.rect.left

                elif self.vel_x < 0:
                    self.rect.left = p.rect.right
                    
    def draw(self, screen):
        #self.sprite.draw()
        screen.draw.rect(self.rect, "cyan")
