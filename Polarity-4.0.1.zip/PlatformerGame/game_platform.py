# platforms.py
from pgzero.builtins import Rect

TILE = 10  # every tile is 10x10 pixels

class Platform:
    def __init__(self, col, row, cols_wide=1, rows_tall=1, friction=0.5, speed_modifier=1.0):
        self.rect = Rect((col * TILE, row * TILE), (cols_wide * TILE, rows_tall * TILE))
        self.friction = friction
        self.speed_modifier = speed_modifier
        self.color = "grey"

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, self.color)


class Lava(Platform):
    def __init__(self, col, row, cols_wide=1, rows_tall=1):
        super().__init__(col, row, cols_wide, rows_tall, friction=0.2, speed_modifier=1.0)
        self.color = "red"


class Ice(Platform):
    def __init__(self, col, row, cols_wide=1, rows_tall=1):
        super().__init__(col, row, cols_wide, rows_tall, friction=1.0, speed_modifier=1.5)
        self.color = "white"


class Speed(Platform):
    def __init__(self, col, row, cols_wide=1, rows_tall=1):
        super().__init__(col, row, cols_wide, rows_tall, friction=0.75, speed_modifier=3.0)
        self.color = "yellow"


class Mud(Platform):
    def __init__(self, col, row, cols_wide=1, rows_tall=1):
        super().__init__(col, row, cols_wide, rows_tall, friction=0.25, speed_modifier=0.5)
        self.color = "brown"


class Finish:
    def __init__(self, col, row, cols_wide=1, rows_tall=1):
        self.rect = Rect((col * TILE, row * TILE), (cols_wide * TILE, rows_tall * TILE))

    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "green")