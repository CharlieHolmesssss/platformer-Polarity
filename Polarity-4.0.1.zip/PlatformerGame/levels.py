from game_platform import Platform, Lava, Ice, Speed, Mud, Finish

LEVELS = [

    # =========================
    # LEVEL 1 — INTRO FLIP
    # =========================
    {
        "player_start": (80, 580),
        "finish": (920, 80, 50, 50),

        "platforms": [

            # box
            Platform(0, 650, 1000, 50),
            Platform(0, 0, 1000, 50),
            Platform(0, 0, 30, 700),
            Platform(970, 0, 30, 700),

            # safe intro path
            Platform(120, 550, 200, 20),
            Platform(350, 450, 200, 20),
            Platform(600, 350, 200, 20),

            # forced flip wall block
            Platform(400, 250, 200, 20),
            Platform(400, 250, 20, 200),

            Ice(650, 550, 150, 20),
        ]
    },

    # =========================
    # LEVEL 2 — GRAVITY SHAFT
    # =========================
    {
        "player_start": (80, 580),
        "finish": (920, 80, 50, 50),

        "platforms": [

            Platform(0, 650, 1000, 50),
            Platform(0, 0, 1000, 50),
            Platform(0, 0, 30, 700),
            Platform(970, 0, 30, 700),

            # main shaft
            Platform(200, 600, 120, 20),
            Platform(200, 500, 120, 20),
            Platform(200, 400, 120, 20),

            # forced flip gap
            Platform(400, 300, 120, 20),
            Platform(400, 200, 120, 20),

            # upside path (requires inverted gravity)
            Platform(600, 200, 200, 20),
            Platform(750, 300, 150, 20),

            Lava(300, 350, 100, 20),
        ]
    },

    # =========================
    # LEVEL 3 — MOMENTUM CONTROL
    # =========================
    {
        "player_start": (80, 580),
        "finish": (920, 80, 50, 50),

        "platforms": [

            Platform(0, 650, 1000, 50),
            Platform(0, 0, 1000, 50),
            Platform(0, 0, 30, 700),
            Platform(970, 0, 30, 700),

            # ice launch section
            Ice(100, 550, 200, 20),
            Ice(350, 500, 200, 20),

            # forced slow zone
            Mud(600, 450, 200, 20),

            # vertical flip tower
            Platform(650, 350, 100, 20),
            Platform(650, 250, 100, 20),
            Platform(650, 150, 100, 20),

            # top route requires flip timing
            Speed(300, 200, 150, 20),

            Lava(500, 300, 120, 20),
        ]
    },

    # =========================
    # LEVEL 4 — GRAVITY PUZZLE
    # =========================
    {
        "player_start": (80, 580),
        "finish": (920, 80, 50, 50),

        "platforms": [

            Platform(0, 650, 1000, 50),
            Platform(0, 0, 1000, 50),
            Platform(0, 0, 30, 700),
            Platform(970, 0, 30, 700),

            # zigzag requiring flips
            Platform(150, 550, 120, 20),
            Platform(300, 450, 120, 20),
            Platform(150, 350, 120, 20),
            Platform(300, 250, 120, 20),

            # inverted route
            Platform(600, 550, 120, 20),
            Platform(750, 450, 120, 20),
            Platform(600, 350, 120, 20),
            Platform(750, 250, 120, 20),

            Ice(450, 150, 120, 20),
            Speed(550, 150, 120, 20),

            Lava(420, 300, 140, 20),
        ]
    }
]