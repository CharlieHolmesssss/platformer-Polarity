from pgzero.builtins import Rect

class Button:

    def __init__(self, x, y, w, h, text, color="blue", hover_color="lightblue"):
        self.rect = Rect((x, y), (w, h))
        self.text = text
        self.color = color
        self.hover_color = hover_color

        self.clicked = False

    def is_hovered(self, pos):
        return self.rect.collidepoint(pos)

    def draw(self, screen, pos):
        hovered = self.is_hovered(pos)

        color = self.hover_color if hovered else self.color

        screen.draw.filled_rect(self.rect, color)

        screen.draw.text(
            self.text,
            center=self.rect.center,
            fontsize=40,
            color="white"
        )

    def check_click(self, pos):
        return self.rect.collidepoint(pos)