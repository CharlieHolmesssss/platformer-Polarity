from pgzero.builtins import Rect, keyboard

class Player:

    def __init__(self, x, y):
        self.rect = Rect((x, y), (25, 25))

        #to make the movement smooth
        self.accel = 0.5
        self.friction = 0.8

        self.vel_x = 0
        self.vel_y = 0
        self.speed = 5

        self.gravity = 0.5
        self.on_ground = False

        #coyote time for responsive jumping/flip - this is what devs use to allow a bit of leeway to make the game feel fai
        self.coyote_time = 0

    def gravity_direction(self):
        #just so jumping works
        return 1 if self.gravity > 0 else -1

    def update(self, platforms):

        #decrease coyote time each frame
        if self.coyote_time > 0:
            self.coyote_time -= 1

        #movement - smooth because of the acceleration and friction
        if keyboard.a:
            self.vel_x -= self.accel

        elif keyboard.d:
            self.vel_x += self.accel

        else:
            self.vel_x *= self.friction

        #limit the speed to stop the acceleration from being to much
        self.vel_x = max(min(self.vel_x, self.speed), -self.speed)

        self.rect.x += self.vel_x

        #X collisions
        self.handle_x_collisions(platforms)


        #gravity
        self.vel_y += self.gravity
        self.rect.y += self.vel_y

        #Y collisions
        self.handle_collisions(platforms)


        #jump (ver 2)
        if not keyboard.w and self.vel_y * self.gravity_direction() < 0:
            self.vel_y *= 0.5

        if keyboard.w and self.on_ground:
            self.vel_y = -10 * self.gravity_direction()

    def flip_gravity(self):
        #only when grounded (now uses coyote time)
        if self.coyote_time > 0:
            self.gravity *= -1
            self.vel_y = 0

            #small instant "kick" so it feels responsive
            self.vel_y = 2 * self.gravity_direction()

    #Y collsions
    def handle_collisions(self, platforms):

        self.on_ground = False

        for p in platforms:

            if self.rect.colliderect(p.rect):

                #gravity down (normal)
                if self.gravity > 0:

                    if self.vel_y > 0:
                        self.rect.bottom = p.rect.top
                        self.vel_y = 0
                        self.on_ground = True

                        #allows instant flip after landing
                        self.coyote_time = 6

                    elif self.vel_y < 0:
                        self.rect.top = p.rect.bottom
                        self.vel_y = 0

                #gravity up (inverted)
                else:

                    if self.vel_y < 0:
                        self.rect.top = p.rect.bottom
                        self.vel_y = 0
                        self.on_ground = True

                        #allows instant flip after landing
                        self.coyote_time = 6

                    elif self.vel_y > 0:
                        self.rect.bottom = p.rect.top
                        self.vel_y = 0

    #X collisions - the sides of platforms and walls
    def handle_x_collisions(self, platforms):

        for p in platforms:

            if self.rect.colliderect(p.rect):

                if self.vel_x > 0:
                    self.rect.right = p.rect.left

                elif self.vel_x < 0:
                    self.rect.left = p.rect.right
                    
    def draw(self, screen):
        screen.draw.filled_rect(self.rect, "cyan")