# IMPORTS
from player import Player
from game_platform import Platform
from levels import LEVELS
import os

# CENTER WINDOW
os.environ['SDL_VIDEO_CENTERED'] = '1'

# SCREEN SETTINGS
WIDTH = 1000
HEIGHT = 700
TITLE = "Polarity"

# GAME STATE
player = None
platforms = []
current_level = 0
finish = None


#initialise

def init_game():
    #Initial setup for full game
    global player, current_level

    current_level = 0
    load_level(current_level)


def load_level(index):
    #Loads a specific level
    global player, platforms, finish

    level = LEVELS[index]

    #create player per level
    player = Player(
        level["player_start"][0],
        level["player_start"][1]
    )

    #load platforms
    platforms = level["platforms"]

    #finish (coded in for now change later)
    finish = Rect((900, 600), (50, 50))


def next_level():
    #Moves to next level
    global current_level

    current_level += 1

    if current_level < len(LEVELS):
        load_level(current_level)
    else:
        print("Game complete!")



#PGZ loop


def update():
    player.update(platforms)

    #level complete
    if player.rect.colliderect(finish):
        next_level()


def draw():
    screen.clear()

    #draw platforms
    for platform in platforms:
        platform.draw(screen)

    #draw player
    player.draw(screen)

    #draw finish zone
    screen.draw.filled_rect(finish, "green")


def on_key_down(key):
    if key == keys.G:
        player.flip_gravity()


#Start Game

init_game()